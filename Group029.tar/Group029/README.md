# Group029 - Hex agent

Group029 members:
- Cristian Osiac
- Eduard Stoica
- Alexandru Staicu
- Dragos Trett

This is Group029's Hex agent submission for COMP34111 AI & Games.

Our agent implementation uses MCTS with heuristics and parallelism.

## Build

This project build using Maven. In this directory run:

```bash
mvn clean install
```

This will output in the `target` directory:
- `hex-{version}-jar-with-dependencies.jar` - Compiled agent uber-jar. This can be run with `java -jar hex-{version}-jar-with-dependencies.jar`
- `Group029.tar` - Tarball that follows coursework submission format.

## Running

The Agent's behaviour is controlled using java system properties. These are passed like:

```bash
java -D{prop.name}={prop.value} ... -jar hex-{version}-jar-with-dependencies.jar
```

Used system properties are:

- `com.prajeala.hex.port` (default: 1234)
  
- `com.prajeala.hex.host` (default: localhost)
  
- `com.prajeala.client.name` (default: client-thread) - Useful when running multiple agents logging to the same stdout 
  pipe.
  
- `com.prajeala.hex.agent` (default: parallel) - Type of client used. Options: default or parallel.

- `com.prajeala.hex.process.iterations` (default: 15000) - Number of process iterations made for each move.

- `com.prajeala.hex.time.enabled` (default: false) - Extra bound for number of process iteration. With this enabled, 
  the agent will process until it has finished `com.prajeala.hex.process.iterations` iterations or 
  `com.prajeala.hex.time.limit` time has passed then choose the best move.
  
- `com.prajeala.hex.time.limit` (default: PT25S) - Upper bound of duration spent processing iteration before each move. 
  Only used when `com.prajeala.hex.time.enabled` is True. Follows this format: 
  https://en.wikipedia.org/wiki/ISO_8601#Durations
  
- `com.prajeala.hex.rollout.iterations` (default: 32) - Number of rollout simulations done for every node. Only used 
  when `com.prajeala.hex.agent` is parallel.
  
- `com.prajeala.hex.parallel.threads` (default: 24) - Number of threads used for processing simulations. Only used
  when `com.prajeala.hex.agent` is parallel.
